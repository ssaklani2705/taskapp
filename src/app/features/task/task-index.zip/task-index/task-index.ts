import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule, MatFormField, MatLabel } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';

import { Component, ElementRef, HostListener, Inject, PLATFORM_ID, ViewChild } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

import { environment } from '../../../../environments/environment';

import { Common } from '../../../classes/common';

import { DataProviderService } from '../../../service/data-provider.service';

import Swal from 'sweetalert2';

import { SessionStorageService } from '../../../service/session-storage.service';

import { SESSION_KEYS } from '../../../service/session-storage.keys';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_LOCALE, MatNativeDateModule, MatOption, MatOptionModule } from '@angular/material/core';
import { MyDateAdapter } from '../../../classes/my-date-adapter';
//import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import * as XLSX from 'xlsx';
import { MatTooltipModule } from '@angular/material/tooltip';

interface Task {
  taskId: number;
  clientName: string;
  date: string;
  dueDateTime: string;
  taskCategoryName: string;
  assignedToName: string;
  priority: number;
  status: number;
  title: string;
  taskStatus: number;
  addedBy: String;
  assignedTo: string;
  assignedbyName: string;
  description: string;
  taskCategoryId: any;
}

interface Client {
  clientId: number;
  name: string;
}

interface TaskCategory {
  taskcategoryId: number;
  name: string;
}

interface AssignedUser {
  userId: number;
  firstName: string;
}

@Component({
  selector: 'app-task-index',
  imports: [CommonModule, FormsModule, RouterModule, MatCardModule, MatDatepickerModule, MatNativeDateModule, MatIconModule, MatDividerModule, MatOptionModule, MatTooltipModule],

  templateUrl: './task-index.html',

  styleUrl: './task-index.scss',
  providers: [
    {
      provide: DateAdapter,
      useClass: MyDateAdapter,
    },
    {
      provide: MAT_DATE_LOCALE,
      useValue: 'en-GB',
    },
  ],
})
export class TaskIndex {
  dashboardFilter: string = '';
  // =========================================================
  // DATA
  // =========================================================
  tasks: Task[] = [];

  apiResponseTaskDetails: any = {};

  loginType = '';
  isHod = '';

  // =========================================================
  // FILTER MASTER DATA
  // =========================================================

  clients: Client[] = [];
  filteredClients: any[] = [];

  taskCategories: TaskCategory[] = [];

  assignedUsers: AssignedUser[] = [];

  // =========================================================
  // SEARCH
  // =========================================================

  searchQuery: string = '';

  search: string = '';

  // =========================================================
  // FILTERS
  // =========================================================

  selectedClient: string = '';
  selectedTaskStatuses: string[] = [];

  selectedTaskCategory: string = '';

  selectedAssignedTo: string = '';

  selectedPriority: string = '';

  selectedStatus: string = '';

  statusIndex: number = 0;

  // =========================================================
  // PAGINATION
  // =========================================================

  currentPage: number = 1;
  selectedTaskStatus: any;

  page: number = 0;

  recordsPerPage: number = environment.recordsPerPage;

  size: number = environment.size;

  // =========================================================
  // OTHER
  // =========================================================

  selectedmodules: any[] = [];

  createdBy: any;

  common = new Common();

  task: any = {};

  userId: any;

  isAdmin: any;

  // =========================================================
  // PERMISSIONS
  // =========================================================

  addPer: string = 'N';

  editPer: string = 'N';

  deletePer: string = 'N';

  viewPer: string = 'N';

  approvePer: string = 'N';

  adminApprovePer: string = 'N';

  exportExcelPer = 'Y';

  moduleName: string = '';

  showHeaderBar: boolean = true;

  // =========================================================
  // SESSION FILTER
  // =========================================================

  filterKey = SESSION_KEYS.TASK_MASTER_FILTER;

  // =========================================================
  // PANEL
  // =========================================================

  isPanelVisible = true;

  // =========================================================
  // SORT
  // =========================================================

  sortColumn: string = '';

  sortDirection: 'asc' | 'desc' = 'asc';

  // =========================================================
  // TABLE COLUMNS
  // =========================================================

  columns: {
    key: string;
    label: string;
    sortable: boolean;
  }[] = [
    {
      key: 'title',
      label: 'Title',
      sortable: true,
    },

    {
      key: 'clientName',
      label: 'Client',
      sortable: true,
    },

    {
      key: 'date',
      label: 'Start Date',
      sortable: true,
    },

    {
      key: 'due_date',
      label: 'Due Date',
      sortable: true,
    },

    {
      key: 'taskCategoryName',
      label: 'Task Category',
      sortable: true,
    },
    {
      key: 'assignedbyName',
      label: 'Assigned By',
      sortable: true,
    },

    {
      key: 'assignedToName',
      label: 'Assigned To',
      sortable: true,
    },

    {
      key: 'priority',
      label: 'Priority',
      sortable: true,
    },
    {
      key: 'taskStatus',
      label: 'Update Status',
      sortable: true,
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
    },
  ];

  // =========================================================
  // CONSTRUCTOR
  // =========================================================

  constructor(
    private dataprovider: DataProviderService,

    @Inject(PLATFORM_ID)
    private platformId: Object,

    private router: Router,

    private route: ActivatedRoute,

    private sessionService: SessionStorageService,
  ) {}

ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.userId = sessionStorage.getItem('userId');
      this.isAdmin = sessionStorage.getItem('isAdmin');
      this.loginType = sessionStorage.getItem('loginType') || 'other';
      this.isHod = sessionStorage.getItem('isHod') || 'N';
      const storedModuleDetail = sessionStorage.getItem('selectedModuleDetail');
      console.log('SELECTED MODULE DETAIL:', storedModuleDetail);
      let moduleDetail: any = null;
      if (storedModuleDetail && storedModuleDetail !== 'null' && storedModuleDetail !== 'undefined') {
        try {
          moduleDetail = JSON.parse(storedModuleDetail);
        } catch (error) {
          console.error('Invalid selectedModuleDetail:', error);
        }
      }
      if (!moduleDetail) {
        const storedModules = sessionStorage.getItem('modules');
        console.log('STORED MODULES:', storedModules);
        if (storedModules) {
          try {
            const modules = JSON.parse(storedModules);
            moduleDetail = modules.find((module: any) => Number(module.moduleId) === 10 || module.name === 'Task');
            console.log('TASK MODULE FROM MODULES:', moduleDetail);
          } catch (error) {
            console.error('Invalid modules session data:', error);
          }
        }
      }
      if (moduleDetail) {
        this.moduleName = moduleDetail.name ?? '';
        this.addPer = moduleDetail.addPer ?? 'N';
        this.editPer = moduleDetail.editPer ?? 'N';
        this.deletePer = moduleDetail.deletePer ?? 'N';
        this.viewPer = moduleDetail.viewPer ?? 'N';
        this.approvePer = moduleDetail.approvePer ?? 'N';
        this.adminApprovePer = moduleDetail.adminApprovePer ?? 'N';
        this.exportExcelPer = moduleDetail.exportExcel ?? 'N';
      }
      console.log('TASK PERMISSIONS:', {
        moduleName: this.moduleName,
        addPer: this.addPer,
        editPer: this.editPer,
        deletePer: this.deletePer,
        viewPer: this.viewPer,
        approvePer: this.approvePer,
        adminApprovePer: this.adminApprovePer,
        exportExcelPer: this.exportExcelPer,
      });
    }
    this.sessionService.clearOtherSessions(this.filterKey);
    this.restoreFilterState();
    this.route.queryParams.subscribe((params) => {
      this.dashboardFilter = params['taskType'] || '';
      // NEW: read statusIndex (1 = Active) from the URL
  if (params['statusIndex'] !== undefined) {
    this.statusIndex = Number(params['statusIndex']) || 0;
    this.selectedStatus = this.statusIndex ? String(this.statusIndex) : '';
    this.currentPage = 1;
    this.page = 0;
  }
      if (params['taskStatusIds'] !== undefined) {
        this.selectedTaskStatuses = params['taskStatusIds']
          ? String(params['taskStatusIds'])
              .split(',')
              .filter((status: string) => status !== '')
          : [];
        this.currentPage = 1;
        this.page = 0;
      }
      if (params['clientId'] !== undefined) {
        this.selectedClient = params['clientId'] ? String(params['clientId']) : '';
        this.currentPage = 1;
        this.page = 0;
      }
      this.loadFilterData();
      this.getTaskDetails();
    });
  }

  private restoreFilterState(): void {
    let stateData: any = null;
    const nav = this.router.getCurrentNavigation();
    stateData = nav?.extras?.state;

     const returningFromDetail =
    isPlatformBrowser(this.platformId) && sessionStorage.getItem('taskReturnFromDetail') === 'Y';

  if (isPlatformBrowser(this.platformId)) {
    sessionStorage.removeItem('taskReturnFromDetail');   // single-use flag
  }

   if (!stateData && returningFromDetail) {
    const saved = sessionStorage.getItem(this.filterKey);

    if (saved) {
      try {
        stateData = JSON.parse(saved);
      } catch (error) {
        console.error('Invalid task filter session:', error);
      }
    }
  }

    if (!stateData) {
      this.currentPage = 1;
      this.page = 0;
      this.size = environment.size;
      this.recordsPerPage = this.size;
      this.search = '';
      this.searchQuery = '';
      this.statusIndex = 0;
      this.selectedStatus = '';
      this.selectedClient = '';
      this.selectedTaskCategory = '';
      this.selectedAssignedTo = '';
      this.selectedPriority = '';
      this.selectedTaskStatuses = [];
      this.fromDate = null;
      this.toDate = null;

      return;
    }

    this.currentPage = Number(stateData.currentPage) || 1;
    this.page = this.currentPage - 1;
    this.size = Number(stateData.size) || environment.size;
    this.recordsPerPage = this.size;
    this.search = stateData.searchText || '';
    this.searchQuery = this.search;
    this.statusIndex = Number(stateData.statusIndex) || 0;
    this.selectedStatus = this.statusIndex ? String(this.statusIndex) : '';
    this.selectedClient = stateData.clientId != null ? String(stateData.clientId) : '';

    this.selectedTaskCategory = stateData.taskCategoryId != null ? String(stateData.taskCategoryId) : '';

    this.selectedAssignedTo = stateData.assignedTo != null ? String(stateData.assignedTo) : '';
    this.selectedPriority = stateData.priority != null ? String(stateData.priority) : '';

    this.selectedTaskStatuses = Array.isArray(stateData.taskStatusId) ? stateData.taskStatusId.map((v: any) => String(v)) : [];
    this.dashboardFilter = stateData.dashboardFilter || '';
    //
    if (Array.isArray(stateData.taskStatusId)) {
      this.selectedTaskStatuses = stateData.taskStatusId.map((v: any) => String(v));
    } else if (stateData.taskStatusId != null && stateData.taskStatusId !== '') {
      this.selectedTaskStatuses = String(stateData.taskStatusId)
        .split(',')
        .filter((v: string) => v !== '');
    } else {
      this.selectedTaskStatuses = [];
    }

    this.fromDate = stateData.fromDate ? new Date(stateData.fromDate + 'T00:00:00') : null;
    this.toDate = stateData.toDate ? new Date(stateData.toDate + 'T00:00:00') : null;
  }

  // private restoreFilterState(): void {
  //   let stateData: any = null;
  //   const nav = this.router.getCurrentNavigation();
  //   stateData = nav?.extras?.state;

  //   if (!stateData) {
  //     const saved = sessionStorage.getItem(this.filterKey);

  //     if (saved) {
  //       try {
  //         stateData = JSON.parse(saved);
  //       } catch (error) {
  //         console.error('Invalid task filter session:', error);
  //       }
  //     }
  //   }

  //   if (!stateData) {
  //     this.currentPage = 1;
  //     this.page = 0;
  //     this.size = environment.size;
  //     this.recordsPerPage = this.size;
  //     this.search = '';
  //     this.searchQuery = '';
  //     this.statusIndex = 0;
  //     this.selectedStatus = '';
  //     this.selectedClient = '';
  //     this.selectedTaskCategory = '';
  //     this.selectedAssignedTo = '';
  //     this.selectedPriority = '';
  //     this.selectedTaskStatuses = [];
  //     this.fromDate = null;
  //     this.toDate = null;

  //     return;
  //   }

  //   this.currentPage = Number(stateData.currentPage) || 1;
  //   this.page = this.currentPage - 1;
  //   this.size = Number(stateData.size) || environment.size;
  //   this.recordsPerPage = this.size;
  //   this.search = stateData.searchText || '';
  //   this.searchQuery = this.search;
  //   this.statusIndex = Number(stateData.statusIndex) || 0;
  //   this.selectedStatus = this.statusIndex ? String(this.statusIndex) : '';
  //   this.selectedClient = stateData.clientId != null ? String(stateData.clientId) : '';

  //   this.selectedTaskCategory = stateData.taskCategoryId != null ? String(stateData.taskCategoryId) : '';

  //   this.selectedAssignedTo = stateData.assignedTo != null ? String(stateData.assignedTo) : '';
  //   this.selectedPriority = stateData.priority != null ? String(stateData.priority) : '';

  //   this.selectedTaskStatuses = Array.isArray(stateData.taskStatusId) ? stateData.taskStatusId.map((v: any) => String(v)) : [];
  //   this.dashboardFilter = stateData.dashboardFilter || '';
  //   //
  //   if (Array.isArray(stateData.taskStatusId)) {
  //     this.selectedTaskStatuses = stateData.taskStatusId.map((v: any) => String(v));
  //   } else if (stateData.taskStatusId != null && stateData.taskStatusId !== '') {
  //     this.selectedTaskStatuses = String(stateData.taskStatusId)
  //       .split(',')
  //       .filter((v: string) => v !== '');
  //   } else {
  //     this.selectedTaskStatuses = [];
  //   }

  //   this.fromDate = stateData.fromDate ? new Date(stateData.fromDate + 'T00:00:00') : null;
  //   this.toDate = stateData.toDate ? new Date(stateData.toDate + 'T00:00:00') : null;
  // }

  // =========================================================
  // SAVE FILTER STATE
  // =========================================================

  private saveFilterState(): void {
    const filterState = {
      currentPage: this.currentPage,

      page: this.page,

      size: this.size,

      statusIndex: this.statusIndex,

      searchText: this.search,

      clientId: this.selectedClient ? Number(this.selectedClient) : null,

      taskCategoryId: this.selectedTaskCategory ? Number(this.selectedTaskCategory) : null,

      assignedTo: this.selectedAssignedTo ? Number(this.selectedAssignedTo) : null,

      priority: this.selectedPriority ? Number(this.selectedPriority) : null,

      fromDate: this.formatDateForApi(this.fromDate),

      toDate: this.formatDateForApi(this.toDate),
      taskStatusId: this.selectedTaskStatuses,
    };

    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem(this.filterKey, JSON.stringify(filterState));
    }
  }

  // =========================================================
  // LOAD FILTER DATA
  // =========================================================

  private loadFilterData(): void {
    this.dataprovider
      .getTaskFilterDataForIndex(this.isAdmin, this.userId, this.loginType,this.isHod)
      .subscribe({
        next: (response: any) => {
          this.clients = response.clients || [];
          this.filteredClients = [...this.clients];
          if (this.selectedClient) {
            const selectedClientObj = this.clients.find(
              (c: any) => String(c.clientId) === String(this.selectedClient),
            );
            //   if (selectedClientObj) {
            //     this.clientSearchText = selectedClientObj.name;
            //   }
            // }
            if (selectedClientObj) {
              this.clientSearchText = selectedClientObj.name;
            } else {
              this.clientSearchText = '';
            }
          } else {
            this.clientSearchText = '';
          }
          this.filterAvailableClients();
          this.taskCategories = response.taskCategories || [];
          this.assignedUsers = response.assignedUsers || [];
        },
        error: (error) => {
          console.error('Error loading task filter data:', error);
          this.clients = [];
          this.filteredClients = [];
          this.taskCategories = [];
          this.assignedUsers = [];
        },
      });
  }


 private filterAvailableClients(): void {
    const availableClientNames = new Set(
      this.tasks.map((task: any) => task.clientName).filter((name: string) => name),
    );
    this.filteredClients = this.clients.filter((client: any) => {
      if (this.selectedClient && String(client.clientId) === String(this.selectedClient)) {
        return true;
      }
      return availableClientNames.has(client.name);
    });
    console.log('AVAILABLE CLIENTS:', this.filteredClients);
  }

  // =========================================================
  // TOGGLE PANEL
  // =========================================================

  togglePanel(): void {
    this.isPanelVisible = !this.isPanelVisible;
  }

  // =========================================================
  // GET TASK DETAILS
  // =========================================================

 getTaskDetails(): void {
    const clientId = this.selectedClient ? Number(this.selectedClient) : 0;
    const taskCategoryId = this.selectedTaskCategory ? Number(this.selectedTaskCategory) : 0;
    const assignedTo = this.selectedAssignedTo ? Number(this.selectedAssignedTo) : -1;
    const priority = this.selectedPriority ? Number(this.selectedPriority) : 0;
    const fromDate = this.formatDateForApi(this.fromDate);
    const toDate = this.formatDateForApi(this.toDate);
    const taskStatusId = this.selectedTaskStatuses;
    this.dataprovider
      .getTaskDetails(
        this.page,
        this.size,
        this.statusIndex,
        this.search,
        clientId,
        taskCategoryId,
        assignedTo,
        priority,
        fromDate,
        toDate,
        this.isAdmin,
        this.userId,
        taskStatusId,
        this.loginType,
        this.dashboardFilter,
        this.isHod
      )
      .subscribe({
        next: (response: any) => {
          console.log('TASK DETAILS RESPONSE:', response);
          this.apiResponseTaskDetails = response;
          this.tasks = response.data || [];
          this.filterAvailableClients();
          // Re-resolve the selected client name.
          // This is important when the selected client has 0 tasks.
          if (this.selectedClient && this.clients.length > 0) {
            const selectedClientObj = this.clients.find(
              (client: any) => String(client.clientId) === String(this.selectedClient),
            );
            if (selectedClientObj) {
              this.clientSearchText = selectedClientObj.name;
            }
          }
        },
        error: (error) => {
          console.error('Error fetching task details:', error);
          this.apiResponseTaskDetails = {
            totalElements: 0,
          };
          this.tasks = [];
        },
      });
  }

  // =========================================================
  // PAGINATED TASKS
  // =========================================================

  get paginatedTasks(): Task[] {
    return this.tasks;
  }

  // =========================================================
  // GO TO PAGE
  // =========================================================

  goToPage(pageNumber: number): void {
    if (pageNumber < 1 || pageNumber > this.totalPages) {
      return;
    }

    this.currentPage = pageNumber;

    this.page = pageNumber - 1;

    this.saveFilterState();

    this.router
      .navigate(
        ['/task-index'],

        {
          replaceUrl: true,
          state: {
            currentPage: this.currentPage,
            statusIndex: this.statusIndex,
            searchText: this.search,
            size: this.size,

            clientId: this.selectedClient || null,
            taskCategoryId: this.selectedTaskCategory || null,
            assignedTo: this.selectedAssignedTo || null,
            priority: this.selectedPriority || null,

            fromDate: this.formatDateForApi(this.fromDate) || null,
            toDate: this.formatDateForApi(this.toDate) || null,

            taskStatusIds: this.selectedTaskStatuses.length > 0 ? this.selectedTaskStatuses : [],

            taskType: this.dashboardFilter || '',
          },
        },
      )
      .then(() => {
        this.getTaskDetails();
      });
  }

  // =========================================================
  // FIRST PAGE
  // =========================================================

  goToFirstPage(): void {
    this.goToPage(1);
  }

  // =========================================================
  // LAST PAGE
  // =========================================================

  goToLastPage(): void {
    this.goToPage(this.totalPages);
  }

  // =========================================================
  // SEARCH / FILTER
  // =========================================================

  // onSearch(): void {

  //   this.search =
  //     this.searchQuery
  //       ? this.searchQuery.trim()
  //       : '';

  //   this.statusIndex =
  //     this.selectedStatus === ''
  //       ? 0
  //       : Number(this.selectedStatus);

  //   this.currentPage = 1;

  //   this.page = 0;

  //   this.saveFilterState();

  //   this.router
  //     .navigate(

  //       ['/task-index'],

  //       {

  //         queryParams: {

  //           currentPage: 1,

  //           page: 0,

  //           size: this.size,

  //           statusIndex:
  //             this.statusIndex,

  //           searchText:
  //             this.search,

  //           clientId:
  //             this.selectedClient || null,

  //           taskCategoryId:
  //             this.selectedTaskCategory || null,

  //           assignedTo:
  //             this.selectedAssignedTo || null,

  //           priority:
  //             this.selectedPriority || null

  //         },

  //         replaceUrl: true

  //       }

  //     )
  //     .then(() => {

  //       this.getTaskDetails();

  //     });

  // }

  onSearch(): void {
    this.search = this.searchQuery ? this.searchQuery.trim() : '';

    this.statusIndex = this.selectedStatus === '' ? 0 : Number(this.selectedStatus);

    this.currentPage = 1;
    this.page = 0;

    const fromDate = this.formatDateForApi(this.fromDate);

    const toDate = this.formatDateForApi(this.toDate);

    this.saveFilterState();

    this.router
      .navigate(['/task-index'], {
        state: {
          currentPage: 1,

          page: 0,

          size: this.size,

          statusIndex: this.statusIndex,

          searchText: this.search,

          clientId: this.selectedClient || null,

          taskCategoryId: this.selectedTaskCategory || null,

          assignedTo: this.selectedAssignedTo || null,

          priority: this.selectedPriority || null,

          fromDate: fromDate || null,

          toDate: toDate || null,

          taskStatusIds: this.selectedTaskStatuses.length ? this.selectedTaskStatuses.join(',') : null,
          taskType: this.dashboardFilter,
        },

        replaceUrl: true,
      })
      .then(() => {
        this.getTaskDetails();
      });
  }

  private formatDateForApi(date: Date | null): string {
    if (!date) {
      return '';
    }

    const year = date.getFullYear();

    const month = String(date.getMonth() + 1).padStart(2, '0');

    const day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  // =========================================================
  // CHANGE RECORDS PER PAGE
  // =========================================================

  onChangeRecordsPerPage(): void {
    this.currentPage = 1;

    this.page = 0;

    this.saveFilterState();

    this.getTaskDetails();
  }

  // =========================================================
  // DELETE TASK
  // =========================================================

  // onDeleteTask(
  //   taskId: number
  // ): void {

  //   // this.task = {

  //   //   taskId:

  //   //     Number(taskId),

  //   //   userId:

  //   //     this.userId
  //   //       ? Number(this.userId)
  //   //       : null

  //   // };

  //   // Swal.fire({

  //   //   title:
  //   //     'Are you sure?',

  //   //   text:
  //   //     'Do you really want to delete this task?',

  //   //   icon:
  //   //     'warning',

  //   //   showCancelButton:
  //   //     true,

  //   //   confirmButtonText:
  //   //     'Yes, delete it!',

  //   //   cancelButtonText:
  //   //     'No, keep it',

  //   // }).then(
  //   //   (result) => {

  //   //     if (
  //   //       result.isConfirmed
  //   //     ) {

  //   //       this.dataprovider
  //   //         .deleteTask(this.task)
  //   //         .subscribe({

  //   //           next:
  //   //             (response: any) => {

  //   //               if (
  //   //                 response.success
  //   //               ) {

  //   //                 Swal.fire(

  //   //                   'Deleted!',

  //   //                   response.message,

  //   //                   'success'

  //   //                 );

  //   //                 this.getTaskDetails();

  //   //               } else {

  //   //                 Swal.fire(

  //   //                   'Error',

  //   //                   response.message,

  //   //                   'error'

  //   //                 );

  //   //               }

  //   //             },

  //   //           error:
  //   //             (error) => {

  //   //               console.error(
  //   //                 'Error deleting task:',
  //   //                 error
  //   //               );

  //   //               Swal.fire(

  //   //                 'Error',

  //   //                 'Something went wrong while deleting the task.',

  //   //                 'error'

  //   //               );

  //   //             }

  //   //         });

  //   //     }

  //   //   }

  //   // );

  // }

  // =========================================================
  // VIEW TASK
  // =========================================================

  viewTask(taskId: number): void {
    this.saveFilterState();

    this.router.navigate(['/view-task', taskId], {
      state: {
        currentPage: this.currentPage,
        statusIndex: this.statusIndex,
        searchText: this.search,
        size: this.size,

        clientId: this.selectedClient || null,
        taskCategoryId: this.selectedTaskCategory || null,
        assignedTo: this.selectedAssignedTo || null,
        priority: this.selectedPriority || null,

        fromDate: this.formatDateForApi(this.fromDate) || null,
        toDate: this.formatDateForApi(this.toDate) || null,

        taskStatusIds: this.selectedTaskStatuses.length > 0 ? this.selectedTaskStatuses : [],

        taskType: this.dashboardFilter || '',
      },
    });
  }

  // =========================================================
  // EDIT TASK
  // =========================================================

  editTask(taskId: number): void {
    this.saveFilterState();

    this.router.navigate(
      ['/edit-task', taskId],

      {
        state: {
          currentPage: this.currentPage,

          statusIndex: this.statusIndex,

          searchText: this.search,

          size: this.size,

          clientId: this.selectedClient || null,

          taskCategoryId: this.selectedTaskCategory || null,

          assignedTo: this.selectedAssignedTo || null,

          priority: this.selectedPriority || null,

          fromDate: this.formatDateForApi(this.fromDate) || null,

          toDate: this.formatDateForApi(this.toDate) || null,

          taskStatusIds: this.selectedTaskStatuses.length ? this.selectedTaskStatuses.join(',') : null,
          taskType: this.dashboardFilter,
        },
      },
    );
  }

  // =========================================================
  // ADD TASK
  // =========================================================
  addTask(): void {
    this.saveFilterState();

    this.router.navigate(
      ['/add-task'],

      {
        state: {
          currentPage: this.currentPage,
          statusIndex: this.statusIndex,
          searchText: this.search,
          size: this.size,

          clientId: this.selectedClient || null,
          taskCategoryId: this.selectedTaskCategory || null,
          assignedTo: this.selectedAssignedTo || null,
          priority: this.selectedPriority || null,

          fromDate: this.formatDateForApi(this.fromDate) || null,
          toDate: this.formatDateForApi(this.toDate) || null,

          taskStatusIds: this.selectedTaskStatuses.length > 0 ? this.selectedTaskStatuses : [],

          taskType: this.dashboardFilter || '',
        },
      },
    );
  }

  // =========================================================
  // PAGE NUMBERS
  // =========================================================

  pages(): number[] {
    const total = this.totalPages;

    const current = this.currentPage;

    const delta = 5;

    const start = Math.max(1, current - delta);

    const end = Math.min(total, current + delta);

    const arr: number[] = [];

    for (let i = start; i <= end; i++) {
      arr.push(i);
    }

    return arr;
  }

  // =========================================================
  // RECORD SUMMARY
  // =========================================================

  get recordSummary(): string {
    const totalRecords = this.apiResponseTaskDetails?.totalElements || 0;

    const startRecord = totalRecords === 0 ? 0 : (this.currentPage - 1) * this.recordsPerPage + 1;

    const endRecord = Math.min(
      this.currentPage * this.recordsPerPage,

      totalRecords,
    );

    return `Page ${this.currentPage} of ${this.totalPages}, (${startRecord} - ${endRecord} of ${totalRecords} record${totalRecords > 1 ? 's' : ''})`;
  }

  // =========================================================
  // TOTAL PAGES
  // =========================================================

  get totalPages(): number {
    const total = this.apiResponseTaskDetails?.totalElements || 0;

    return Math.max(
      1,

      Math.ceil(total / this.recordsPerPage),
    );
  }

  // =========================================================
  // SORT
  // =========================================================

  sortData(column: string): void {
    if (!column) {
      return;
    }

    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;

      this.sortDirection = 'asc';
    }

    this.tasks.sort((a: any, b: any) => {
      let valA = a[column];

      let valB = b[column];

      valA = valA ?? '';

      valB = valB ?? '';

      if (!isNaN(valA) && !isNaN(valB)) {
        valA = Number(valA);

        valB = Number(valB);
      } else {
        valA = valA.toString().toLowerCase();

        valB = valB.toString().toLowerCase();
      }

      if (valA < valB) {
        return this.sortDirection === 'asc' ? -1 : 1;
      }

      if (valA > valB) {
        return this.sortDirection === 'asc' ? 1 : -1;
      }

      return 0;
    });
  }

  // =========================================================
  // PRIORITY LABEL
  // =========================================================

  getPriorityLabel(priority: number): string {
    switch (priority) {
      case 1:
        return 'High';

      case 2:
        return 'Medium';

      case 3:
        return 'Low';

      default:
        return '-';
    }
  }

  // =========================================================
  // PRIORITY CSS
  // =========================================================

  getPriorityClass(priority: number): string {
    switch (priority) {
      case 1:
        return 'priority-high';

      case 2:
        return 'priority-medium';

      case 3:
        return 'priority-low';

      default:
        return '';
    }
  }

  // =========================================================
  // CLEAR FILTERS
  // =========================================================

  clearFilters(): void {
    this.showStatusDropdown = false;
    // Clear search
    this.searchQuery = '';
    this.search = '';

    // Clear dropdown filters
    this.selectedClient = '';
    this.clientSearchText = '';
    this.filteredClients = [...this.clients];
    this.selectedTaskCategory = '';
    this.selectedAssignedTo = '';
    this.selectedPriority = '';
    this.selectedStatus = '';
    this.selectedTaskStatuses = [];

    // Clear dates
    this.fromDate = null;
    this.toDate = null;

    // Reset status
    this.statusIndex = 0;

    // Reset pagination
    this.currentPage = 1;
    this.page = 0;

    // Reset sorting
    this.sortColumn = '';
    this.sortDirection = 'asc';

    // Save cleared filter state
    this.saveFilterState();

    this.router
      .navigate(['/task-index'], {
        state: {
          currentPage: 1,

          page: 0,

          size: this.size,

          statusIndex: 0,

          searchText: '',

          clientId: null,

          taskCategoryId: null,

          assignedTo: null,

          priority: null,

          fromDate: null,

          toDate: null,
          taskStatusId: null,
        },

        replaceUrl: true,
      })
      .then(() => {
        this.getTaskDetails();
      });
  }

  onDeleteTask(taskId: number): void {
    this.task = {
      taskId: Number(taskId),
      createdBy: this.userId ? Number(this.userId) : null,
    };

    Swal.fire({
      title: 'Are you sure?',
      text: 'Do you really want to delete this task?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it',
      confirmButtonColor: '#d33',
      cancelButtonColor: '#6c757d',
      customClass: {
        popup: 'small-confirm-popup',
      },
    }).then((result) => {
      if (result.isConfirmed) {
        this.dataprovider.deleteTask(this.task).subscribe({
          next: (response: any) => {
            if (response.success) {
              Swal.fire('Deleted!', response.message, 'success');

              this.getTaskDetails();
            } else {
              Swal.fire('Error', response.message, 'error');
            }
          },

          error: (error) => {
            console.error('Error deleting task:', error);

            Swal.fire('Error', 'Something went wrong while deleting the task.', 'error');
          },
        });
      }
    });
  }

  fromDate: Date | null = null;

  toDate: Date | null = null;

  isTaskOwner(task: any): boolean {
    return Number(task.addedBy) === Number(this.userId);
  }

  isTaskAssignedToUser(task: any): boolean {
    return Number(task.status) !== 3 && (Number(task.assignedTo) === Number(this.userId) || Number(task.addedBy) === Number(this.userId));
  }

  //for model note
  showTaskNotesModal = false;

  isAddingNote = false;

  selectedTask: any = null;

  taskNote = '';

  taskNotes: any[] = [];

  isSavingTaskNote = false;

  openTaskNotes(task: any): void {
    this.selectedTask = task;

    // Initially DON'T show add form
    this.isAddingNote = false;

    this.taskNote = '';

    this.showTaskNotesModal = true;

    // Load previous notes
    this.loadTaskNotes(task.taskId);
  }

  loadTaskNotes(taskId: number): void {
    this.dataprovider.getTaskNotes(taskId).subscribe({
      next: (response: any[]) => {
        console.log('Task notes:', response);

        this.taskNotes = response || [];
      },

      error: (error) => {
        console.error('Error loading task notes:', error);

        this.taskNotes = [];
      },
    });
  }

  startAddingNote(): void {
    this.isAddingNote = true;

    this.taskNote = '';
  }

  cancelAddingNote(): void {
    this.isAddingNote = false;

    this.taskNote = '';
  }

  closeTaskNotesModal(): void {
    if (this.isSavingTaskNote) {
      return;
    }

    this.showTaskNotesModal = false;

    this.selectedTask = null;

    this.taskNote = '';
  }

  saveTaskNote(): void {
    if (!this.taskNote?.trim()) {
      return;
    }

    if (!this.selectedTask?.taskId) {
      return;
    }

    this.isSavingTaskNote = true;

    const request = {
      taskId: this.selectedTask.taskId,
      note: this.taskNote.trim(),
      userId: this.userId,
      sendMail: this.sendMail,
      isAdmin: this.isAdmin,
    };

    this.dataprovider.addTaskNote(request).subscribe({
      next: () => {
        this.taskNote = '';

        // Hide Add Note form after successful submit
        this.isAddingNote = false;
        this.sendMail = false;

        this.isSavingTaskNote = false;

        // Reload previous notes
        this.loadTaskNotes(this.selectedTask.taskId);
      },

      error: (error) => {
        console.error('Error saving task note', error);

        this.isSavingTaskNote = false;
      },
    });
  }

  getCreatorInitial(name: string): string {
    if (!name || !name.trim()) {
      return '?';
    }

    return name.trim().charAt(0).toUpperCase();
  }

  getCreatorColor(name: string): string {
    if (!name || !name.trim()) {
      return '#64748b';
    }

    const colors = [
      '#2563eb', // Blue
      '#7c3aed', // Purple
      '#db2777', // Pink
      '#dc2626', // Red
      '#ea580c', // Orange
      '#16a34a', // Green
      '#0891b2', // Cyan
      '#4f46e5', // Indigo
      '#ca8a04', // Yellow
      '#0f766e', // Teal
    ];

    let hash = 0;

    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }

    const index = Math.abs(hash) % colors.length;

    return colors[index];
  }

  // =========================================================
  // CHANGE MANAGER / TASK FILES MODAL
  // =========================================================

  showChangeManagerModal = false;
  isChangingManager = false;

  taskDescription: string = '';
  descriptionValidationError = false;

  fileOne: File | null = null;
  fileOneName: string = '';

  fileTwo: File | null = null;
  fileTwoName: string = '';

  openChangeManagerModal(taskObject: any): void {
    //  console.log("sssssssss" + taskObject);
    this.descriptionValidationError = false;

    this.selectedTaskStatusIdForCondition = taskObject.taskStatus;

    // this. selectedTaskStatusId= taskObject.taskStatus;
    this.task = {
      taskId: taskObject.taskId,
      managerId: taskObject.managerId,
      addedBy: taskObject.addedBy,
      assignedTo: taskObject.assignedTo,
      taskStatus: taskObject.taskStatus,
    };

    //  console.log("{ == }" + JSON.stringify(this.task));

    this.taskDescription = '';

    this.fileOne = null;
    this.fileOneName = '';

    this.fileTwo = null;
    this.fileTwoName = '';

    this.showChangeManagerModal = true;
  }

  closeChangeManagerModal(): void {
    if (this.isChangingManager) {
      return;
    }

    this.showChangeManagerModal = false;

    this.taskDescription = '';

    this.fileOne = null;
    this.fileOneName = '';

    this.fileTwo = null;
    this.fileTwoName = '';

    this.descriptionValidationError = false;
  }

  // private readonly MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

  // onFileOneSelected(event: Event): void {

  //   const input = event.target as HTMLInputElement;

  //   if (input.files && input.files.length > 0) {

  //     const file = input.files[0];

  //     // ZIP validation
  //     if (!file.name.toLowerCase().endsWith('.zip')) {
  //       Swal.fire('Error', 'Only ZIP files are allowed.', 'error');

  //       input.value = '';
  //       this.fileOne = null;
  //       this.fileOneName = '';
  //       return;
  //     }

  //     if (file.size > this.MAX_FILE_SIZE) {
  //       Swal.fire('Error', 'ZIP file size must not exceed 5 MB.', 'error');

  //       input.value = '';
  //       this.fileOne = null;
  //       this.fileOneName = '';
  //       return;
  //     }

  //     this.fileOne = file;
  //     this.fileOneName = file.name;

  //   } else {
  //     this.fileOne = null;
  //     this.fileOneName = '';
  //   }
  // }

  // onFileTwoSelected(event: Event): void {

  //   const input = event.target as HTMLInputElement;

  //   if (input.files && input.files.length > 0) {

  //     const file = input.files[0];

  //     // PDF validation
  //     if (!file.name.toLowerCase().endsWith('.pdf')) {
  //       Swal.fire('Error', 'Only PDF files are allowed.', 'error');

  //       input.value = '';
  //       this.fileTwo = null;
  //       this.fileTwoName = '';
  //       return;
  //     }

  //     if (file.size > this.MAX_FILE_SIZE) {
  //       Swal.fire('Error', 'PDF file size must not exceed 5 MB.', 'error');

  //       input.value = '';
  //       this.fileTwo = null;
  //       this.fileTwoName = '';
  //       return;
  //     }

  //     this.fileTwo = file;
  //     this.fileTwoName = file.name;

  //   } else {
  //     this.fileTwo = null;
  //     this.fileTwoName = '';
  //   }
  // }
  selectedTaskStatusId: number = 5;
  selectedTaskStatusIdForCondition: number = 0;
  //  selectedTaskStatusId: number = 0;

  // Add near your other class constants (replace/update MAX_FILE_SIZE if it's currently set to 5 MB)
  readonly MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

  readonly ALLOWED_EXTENSIONS_FILE_ONE = ['.pdf', '.xls', '.xlsx', '.doc', '.docx', '.zip'];
  readonly ALLOWED_EXTENSIONS_FILE_TWO = ['.pdf', '.xls', '.xlsx', '.doc', '.docx'];

  onFileOneSelected(event: Event): void {
    const input = event.target as HTMLInputElement;

    if (input.files && input.files.length > 0) {
      const file = input.files[0];

      const fileName = file.name.toLowerCase();

      const isAllowedType = this.ALLOWED_EXTENSIONS_FILE_ONE.some((ext) => fileName.endsWith(ext));

      if (!isAllowedType) {
        Swal.fire('Error', 'Only .pdf, .xls, .xlsx, .doc, .docx, .zip files are allowed.', 'error');

        input.value = '';
        this.fileOne = null;
        this.fileOneName = '';
        return;
      }

      if (file.size > this.MAX_FILE_SIZE) {
        Swal.fire('Error', 'File size must not exceed 10 MB.', 'error');

        input.value = '';
        this.fileOne = null;
        this.fileOneName = '';
        return;
      }

      this.fileOne = file;
      this.fileOneName = file.name;
    } else {
      this.fileOne = null;
      this.fileOneName = '';
    }
  }

  onFileTwoSelected(event: Event): void {
    const input = event.target as HTMLInputElement;

    if (input.files && input.files.length > 0) {
      const file = input.files[0];

      const fileName = file.name.toLowerCase();

      const isAllowedType = this.ALLOWED_EXTENSIONS_FILE_TWO.some((ext) => fileName.endsWith(ext));

      if (!isAllowedType) {
        Swal.fire('Error', 'Only .pdf, .xls, .xlsx, .doc, .docx files are allowed.', 'error');

        input.value = '';
        this.fileTwo = null;
        this.fileTwoName = '';
        return;
      }

      if (file.size > this.MAX_FILE_SIZE) {
        Swal.fire('Error', 'File size must not exceed 10 MB.', 'error');

        input.value = '';
        this.fileTwo = null;
        this.fileTwoName = '';
        return;
      }

      this.fileTwo = file;
      this.fileTwoName = file.name;
    } else {
      this.fileTwo = null;
      this.fileTwoName = '';
    }
  }

  changeManager(): void {
    if (!this.taskDescription || !this.taskDescription.trim()) {
      this.descriptionValidationError = true;
      return;
    }

    this.descriptionValidationError = false;
    this.isChangingManager = true;

    const formData = new FormData();
    for (const pair of formData.entries()) {
      console.log(pair[0], pair[1]);
    }

    formData.append('selectedTaskStatusId', String(this.selectedTaskStatusId));
    formData.append('taskId', String(this.task.taskId));
    formData.append('description', this.taskDescription.trim());
    formData.append('userId', this.userId);

    if (this.fileTwo) {
      formData.append('fileName3', this.fileTwo, this.fileTwo.name); // normal file → fileName1 (pdf)
    }

    if (this.fileOne) {
      formData.append('fileName4', this.fileOne, this.fileOne.name);
    }

    this.dataprovider.updateTaskDetails(formData).subscribe({
      next: (response: any) => {
        this.isChangingManager = false;
        if (response.success) {
          Swal.fire('Updated!', response.message, 'success');
          this.showChangeManagerModal = false;
          this.getTaskDetails();
        } else {
          Swal.fire('Error', response.message, 'error');
        }
      },
      error: (error) => {
        this.isChangingManager = false;
        console.error('Full error:', error); // add this
        console.error('Backend message:', error?.error?.message); // and this
        Swal.fire('Error', error?.error?.message || 'Something went wrong while updating the task.', 'error');
      },
    });
  }

  exportToExcel(): void {
    // Make sure there is data
    if (!this.tasks || this.tasks.length === 0) {
      alert('No tasks available for export.');
      return;
    }

    const exportData = this.tasks.map((task: any, index: number) => {
      return {
        // 1. Sr. No.
        'Sr. No.': index + 1,

        // 2. Title
        Title: task.title || '-',

        // 3. Client
        Client: task.clientName || '-',

        // 4. Date
        Date: task.date ? this.formatExcelDate(task.date) : '-',

        // 5. Due Date
        'Due Date': task.dueDateTime ? this.formatExcelDate(task.dueDateTime) : '-',

        // 6. Task Category
        'Task Category': task.taskCategoryName || '-',

        // 7. Assigned By
        'Assigned By': task.assignedbyName || '-',

        // 8. Assigned To
        'Assigned To': !task.assignedToName || task.assignedToName === '0' ? 'Unassigned User' : task.assignedToName,

        // 9. Priority
        Priority: this.getPriorityLabel(task.priority),

        // 10. Task Status
        'Task Status': this.common.getTaskStatusLabel(task.taskStatus),

        // 11. Status
        Status: this.common.getStatusLabel(task.status),
      };
    });

    // Create worksheet
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData);

    // Set column widths
    worksheet['!cols'] = [
      { wch: 8 }, // Sr. No.
      { wch: 35 }, // Title
      { wch: 25 }, // Client
      { wch: 20 }, // Date
      { wch: 20 }, // Due Date
      { wch: 25 }, // Task Category
      { wch: 25 }, // Assigned By
      { wch: 25 }, // Assigned To
      { wch: 15 }, // Priority
      { wch: 20 }, // Task Status
      { wch: 15 }, // Status
    ];

    // Create workbook
    const workbook: XLSX.WorkBook = XLSX.utils.book_new();

    // Add worksheet
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Tasks');

    // Generate file name
    const today = new Date();

    const dateString = `${today.getFullYear()}-` + `${String(today.getMonth() + 1).padStart(2, '0')}-` + `${String(today.getDate()).padStart(2, '0')}`;

    // Download Excel
    XLSX.writeFile(workbook, `Tasks_${dateString}.xlsx`);
  }

  // exportToExcel(): void {

  //   // Make sure there is data
  //   if (!this.tasks || this.tasks.length === 0) {
  //     console.warn('No tasks available for export.');
  //     return;
  //   }

  //   const exportData = this.tasks.map((task: any, index: number) => {

  //     return {
  //       'Sr. No.': index + 1,

  //       'Title': task.title || '-',

  //       'Client': task.clientName || '-',

  //       'Date': task.date
  //         ? this.formatExcelDate(task.date)
  //         : '-',

  //       'Task Category': task.taskCategoryName || '-',

  //       'Assigned To': task.assignedToName || '-',

  //       'Priority': this.getPriorityLabel(task.priority),

  //       'Task Status': this.common.getTaskStatusLabel(
  //         task.taskStatus
  //       ),

  //       'Status': this.common.getStatusLabel(
  //         task.status
  //       )
  //     };

  //   });

  //   // Create worksheet
  //   const worksheet: XLSX.WorkSheet =
  //     XLSX.utils.json_to_sheet(exportData);

  //   // Set column widths
  //   worksheet['!cols'] = [
  //     { wch: 6 },    // #
  //     { wch: 35 },   // Title
  //     { wch: 25 },   // Client
  //     { wch: 15 },   // Date
  //     { wch: 25 },   // Task Category
  //     { wch: 25 },   // Assigned To
  //     { wch: 15 },   // Priority
  //     { wch: 20 },   // Task Status
  //     { wch: 15 }    // Status
  //   ];

  //   // Create workbook
  //   const workbook: XLSX.WorkBook =
  //     XLSX.utils.book_new();

  //   XLSX.utils.book_append_sheet(
  //     workbook,
  //     worksheet,
  //     'Tasks'
  //   );

  //   // Generate file name
  //   const today = new Date();

  //   const dateString =
  //     `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

  //   // Download Excel
  //   XLSX.writeFile(
  //     workbook,
  //     `Tasks_${dateString}.xlsx`
  //   );
  // }

  private formatExcelDate(date: any): string {
    if (!date) {
      return '-';
    }

    const parsedDate = new Date(date);

    if (isNaN(parsedDate.getTime())) {
      return '-';
    }

    const day = String(parsedDate.getDate()).padStart(2, '0');

    const month = String(parsedDate.getMonth() + 1).padStart(2, '0');

    const year = parsedDate.getFullYear();

    return `${day}-${month}-${year}`;
  }

  showStatusDropdown = false;

  onStatusChange(event: any): void {
    const value = event.target.value;

    if (event.target.checked) {
      this.selectedTaskStatuses.push(value);
    } else {
      this.selectedTaskStatuses = this.selectedTaskStatuses.filter((x) => x !== value);
    }

    this.onSearch();
  }

  taskStatusOptions: { id: string; label: string }[] = [
    { id: '-1', label: 'Unassigned' },
    { id: '1', label: 'Assigned' },
    { id: '2', label: 'Assignee Closure' },
    { id: '3', label: 'Re-Open' },
    { id: '4', label: 'Assignee Re-Closure' },
    { id: '5', label: 'Assignor Closure' },
  ];

  toggleTaskStatus(id: string): void {
    const index = this.selectedTaskStatuses.indexOf(id);

    if (index > -1) {
      this.selectedTaskStatuses = this.selectedTaskStatuses.filter((x) => x !== id);
    } else {
      this.selectedTaskStatuses = [...this.selectedTaskStatuses, id];
    }

    console.log('selectedTaskStatuses:', this.selectedTaskStatuses);

    this.onSearch();
  }

  isTaskStatusChecked(id: string): boolean {
    return this.selectedTaskStatuses.includes(id);
  }

  showDescriptionModal = false;
  selectedDescriptionTask: any = null;

  openDescriptionModal(task: Task): void {
    this.selectedDescriptionTask = task;

    this.showDescriptionModal = true;
  }

  closeDescriptionModal(): void {
    this.showDescriptionModal = false;

    this.selectedDescriptionTask = null;
  }

  //Assign To Model
  showAssignUserModal = false;
  selectedAssignTask: any = null;
  assignRemarks: string = '';
  users: any[] = [];

  openAssignUserModal(task: any): void {
    const currentAssignedUserId = Number(task.assignedTo || 0);

    this.selectedAssignTask = {
      ...task,
      assignedTo: 0,
    };

    this.assignRemarks = '';

    this.showAssignUserModal = true;
    this.users = [];

    this.dataprovider.changesCategoryIdgetUserFilterData(this.isAdmin, this.userId, this.loginType, task.clientId, task.taskCategoryId).subscribe({
      next: (res: any) => {
        const data = res?.data || res;

        const allUsers = data?.assignedUsers || [];

        this.users = allUsers.filter((user: any) => Number(user.userId) !== currentAssignedUserId);

        console.log('Current assigned user:', currentAssignedUserId);
        console.log('Filtered users:', this.users);
      },

      error: (error: any) => {
        console.error('Error loading assigned users:', error);
        this.users = [];
      },
    });
  }

  closeAssignUserModal(): void {
    this.showAssignUserModal = false;
    this.selectedAssignTask = null;
    this.assignRemarks = '';
    this.users = [];
  }

  assignUser(): void {
    if (!this.selectedAssignTask || !this.selectedAssignTask.assignedTo || this.selectedAssignTask.assignedTo == 0) {
      return;
    }

    // Remarks required only when re-assigning an already-assigned task
    if (this.selectedAssignTask.taskStatus === 1 && !this.assignRemarks?.trim()) {
      return;
    }

    const taskId = this.selectedAssignTask.taskId;
    const assignedTo = this.selectedAssignTask.assignedTo;
    const remarks = this.assignRemarks?.trim() || '';

    this.dataprovider.updateTaskAssignedUser(taskId, assignedTo, this.userId, remarks).subscribe({
      next: (res: any) => {
        if (res?.success) {
          // Find selected user
          const selectedUser = this.users.find((user: any) => user.userId == assignedTo);

          // Update original table task only after API success
          const taskIndex = this.paginatedTasks.findIndex((task: any) => task.taskId == taskId);

          if (taskIndex !== -1) {
            this.paginatedTasks[taskIndex].assignedTo = assignedTo;

            this.paginatedTasks[taskIndex].assignedToName = selectedUser?.firstName || 'Unassigned User';
          }

          this.closeAssignUserModal();

          // Optional: refresh table from backend
          this.onSearch();
        } else {
          console.error('Failed to assign user:', res?.message);
        }
      },

      error: (error: any) => {
        console.error('Error assigning user:', error);
      },
    });
  }

  onchangeloadUserDropdownData(task: any): void {
    this.dataprovider.changesCategoryIdgetUserFilterData(this.isAdmin, this.userId, this.loginType, task.clientId, task.taskCategoryId).subscribe({
      next: (res: any) => {
        const data = res?.data || res;

        this.users = data?.assignedUsers || [];
      },
      error: (error: any) => {
        console.error('Error loading task dropdown data:', error);

        this.users = [];
      },
    });
  }

  // openAssignUserModal(task: any): void {
  //   this.selectedAssignTask = task;
  //   this.showAssignUserModal = true;

  //   this.onchangeloadUserDropdownData(task);
  // }

  //old working
  // canDisableChangeManager(task: any): boolean {
  //   console.log(task);
  //    // Status 5 => closed, locked for everyone, no exceptions (including admin)
  // // if (task.taskStatus == 5) {
  // //   return true;
  // // }

  //   // Admin can perform any action
  //   if (this.isAdmin === 'Y') {
  //     return false;
  //   }

  //   const isManager = Number(task.managerId) === Number(this.userId);

  //   // Status 5 => closed, locked for everyone, no exceptions
  //   if (task.taskStatus == 5) {
  //     return true;
  //   }
  //   // const isAssignor = this.task.addedBy == this.userId;
  //   const selfAssigned =
  //     task.addedBy == task.assignedTo

  //   if (selfAssigned) {
  //     return false;
  //   }
  //   return (
  //     (task.addedBy == this.userId &&
  //       (task.taskStatus == 1 || task.taskStatus == 3)) ||

  //     (task.assignedTo == this.userId &&
  //       (task.taskStatus == 2 || task.taskStatus == 4))
  //   );
  // }

  // canDisableChangeManager(task: any): boolean {
  //   // Status 5 => closed, locked for everyone, no exceptions
  //   if (task.taskStatus == 5) {
  //     return true;
  //   }

  //   // Admin can perform any action
  //   if (this.isAdmin === 'Y') {
  //     return false;
  //   }

  //   const selfAssigned = task.addedBy == task.assignedTo;

  //   if (selfAssigned) {
  //     return false;
  //   }

  //   const canAct =
  //     (task.addedBy == this.userId && (task.taskStatus == 1 || task.taskStatus == 3)) ||
  //     (task.assignedTo == this.userId && (task.taskStatus == 2 || task.taskStatus == 4));

  //   // Anyone who isn't addedBy/assignedTo with a matching status
  //   // is locked out by default.
  //   return !canAct;
  // }


//   canDisableChangeManager(task: any): boolean {

//   // Status 5 => closed, locked for everyone, no exceptions (including admin)
//   if (task.taskStatus == 5) {
//     return true;
//   }

//   // Admin can perform any action
//   if (this.isAdmin === 'Y') {
//     return false;
//   }

//   const selfAssigned = task.addedBy == task.assignedTo;

//   if (selfAssigned) {
//     return false;
//   }

//   // ============================================================
//   // MANAGER
//   // ============================================================
//   if (this.loginType === 'manager') {

//     const canAct =
//       (task.addedBy == this.userId &&
//         (task.taskStatus == 1 || task.taskStatus == 3)) ||
//       (task.assignedTo == this.userId &&
//         (task.taskStatus == 2 || task.taskStatus == 4));

//     return canAct;
//   }

//   // ============================================================
//   // EMPLOYEE
//   // ============================================================
//   return (
//     (task.addedBy == this.userId &&
//       (task.taskStatus == 1 || task.taskStatus == 3)) ||

//     (task.assignedTo == this.userId &&
//       (task.taskStatus == 2 || task.taskStatus == 4))
//   );
// }

  isStatusRadioDisabled(task: any): boolean {
    const selfAssigned = task.addedBy == this.userId && task.assignedTo == this.userId;
    const isManager = task.managerId == this.userId;
    // console.log("{} is manager only " + isManager)
    return isManager;
  }

  canShowAssignorClosure(): boolean {
    // console.error("Inside method checking !!!!")
    // console.error("{this.userId }" + this.userId)

    console.error('{this.managerId }' + this.task.addedBy, this.task.managerId, this.task.assignedTo);
    const isManager = this.task.managerId == this.userId;

    const isAssignor = this.task.addedBy == this.userId;
    const isSelfAssigned = this.task.addedBy == this.task.assignedTo;

    return isManager || (isAssignor && !isSelfAssigned);
  }

  getDueDateClass(dueDateTime: string): string {
    const due = new Date(dueDateTime);
    const now = new Date();

    const dueDay = new Date(due.getFullYear(), due.getMonth(), due.getDate());
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    if (due < now) {
      return 'due-overdue';
    } else if (dueDay.getTime() === today.getTime()) {
      return 'due-today';
    } else {
      return 'due-upcoming';
    }
  }

  removeZipFile(fileInput: HTMLInputElement): void {
    this.fileOne = null;
    this.fileOneName = '';
    fileInput.value = '';
  }

  removeNormalFile(fileInput: HTMLInputElement): void {
    this.fileTwo = null;
    this.fileTwoName = '';
    fileInput.value = '';
  }

  clientSearchText: string = '';
  showClientDropdown: boolean = false;

  selectedClientId: number = 0;

  // filteredClients: any[] = [];

  filterClients(): void {
    const search = this.clientSearchText.toLowerCase().trim();

    if (search.length < 3) {
      this.showClientDropdown = false;
      this.filteredClients = [];
      return;
    }

    this.filteredClients = this.clients.filter((client: any) => client.name && client.name.toLowerCase().includes(search));

    this.showClientDropdown = true;

    // If search is cleared, reset client filter
    if (!search) {
      this.selectedClient = '';

      this.filteredClients = [...this.clients];
    }
  }

  selectClient(client: any): void {
    this.clientSearchText = client.name;

    // This is the value used by your filters/API
    this.selectedClient = String(client.clientId);

    this.showClientDropdown = false;

    // Load data immediately
    this.onSearch();
  }

  clearClientSearch(): void {
    this.clientSearchText = '';
    this.selectedClientId = 0;
    this.selectedClient = '';

    this.filteredClients = [];
    this.showClientDropdown = false;

    this.onSearch(); // Reload all records
  }
  sendMail: boolean = false;
  showTaskCategoryDropdown = false;

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event): void {
    const target = event.target as HTMLElement;

    // Status dropdown
    if (!target.closest('.status-dropdown')) {
      this.showStatusDropdown = false;
    }

    // Client dropdown
    if (!target.closest('.client-dropdown-container')) {
      this.showClientDropdown = false;
    }

    // Task Category dropdown
    if (!target.closest('.task-category-dropdown')) {
      this.showTaskCategoryDropdown = false;
    }
  }


//   canDisableChangeManager(task: any): boolean {

//       // Inactive (2) or Deleted (3) task => locked for everyone, no exceptions (including admin)
//   if (Number(task.status) === 2 || Number(task.status) === 3) {
//     return true;
//   }

//   // Status 5 => closed, locked for everyone, no exceptions (including admin)
//   if (task.taskStatus == 5) {
//     return true;
//   }

//   // Admin can perform any action
//   if (this.isAdmin === 'Y') {
//     return false;
//   }

//   const selfAssigned = task.addedBy == task.assignedTo;

//   if (selfAssigned) {
//     return false;
//   }

//   // ============================================================
//   // MANAGER
//   // ============================================================
//   if (this.loginType === 'manager') {

//     const canAct =
//       (task.addedBy == this.userId &&
//         (task.taskStatus == 1 || task.taskStatus == 3)) ||
//       (task.assignedTo == this.userId &&
//         (task.taskStatus == 2 || task.taskStatus == 4));

//     return canAct;
//   }

//   // ============================================================
//   // EMPLOYEE
//   // ============================================================
//   return (
//     (task.addedBy == this.userId &&
//       (task.taskStatus == 1 || task.taskStatus == 3)) ||

//     (task.assignedTo == this.userId &&
//       (task.taskStatus == 2 || task.taskStatus == 4))
//   );
// }
canDisableChangeManager(task: any): boolean {
  // Inactive (2) or Deleted (3) task => locked for everyone (including admin)
  if (Number(task.status) === 2 || Number(task.status) === 3) {
    return true;
  }

  // Task status 5 => closed, locked for everyone (including admin)
  if (Number(task.taskStatus) === 5) {
    return true;
  }

  // Admin can perform any action
  if (this.isAdmin === 'Y') {
    return false;
  }

  const userId = Number(this.userId);
  const isAssignor = Number(task.addedBy) === userId;
  const isAssignee = Number(task.assignedTo) === userId;
  const isManager = Number(task.managerId) === userId;

  // Self-assigned task: only that user can act
  if (isAssignor && isAssignee) {
    return false;
  }

  const taskStatus = Number(task.taskStatus);
  let canAct = false;

  // Assigned (1) / Re-Open (3): assignee has to submit work
  if (taskStatus === 1 || taskStatus === 3) {
    canAct = isAssignee;
  }

  // Assignee Closure (2) / Assignee Re-Closure (4): assignor (or client manager) reviews
  else if (taskStatus === 2 || taskStatus === 4) {
    canAct = isAssignor || isManager;
  }

  // Button is disabled unless the user is allowed to act
  return !canAct;
}


getSelectedTaskStatusLabel(): string {
  if (this.selectedTaskStatuses.length === 0) {
    return '--All Task Status--';
  }

  const labels = this.taskStatusOptions
    .filter((s) => this.selectedTaskStatuses.includes(s.id))
    .map((s) => s.label);

  // Long lists get shortened so the button doesn't overflow
  if (labels.length > 2) {
    return `${labels.length} statuses selected`;
  }

  return labels.join(', ');
}
}
