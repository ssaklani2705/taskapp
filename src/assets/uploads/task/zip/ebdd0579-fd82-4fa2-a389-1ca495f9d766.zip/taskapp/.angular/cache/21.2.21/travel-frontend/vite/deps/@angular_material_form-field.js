import {
  MatFormFieldModule
} from "./chunk-C27Y62TI.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-YVYE6KWR.js";
import "./chunk-EV3ZV2KF.js";
import "./chunk-2ITJWV2V.js";
import "./chunk-PLJ2QXBA.js";
import "./chunk-N4DOILP3.js";
import "./chunk-DUQJKPQC.js";
import "./chunk-OOVWQHNU.js";
import "./chunk-T7DNYQFY.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-LLCNFE3V.js";
import "./chunk-72DZ2VPG.js";
import "./chunk-RR3WQQDB.js";
import "./chunk-O7KM5E7H.js";
import "./chunk-REEJUJYK.js";
import "./chunk-LVBZNVGU.js";
import "./chunk-JCADZX2L.js";
import "./chunk-HWYXSU2G.js";
import "./chunk-JRFR6BLO.js";
import "./chunk-MARUHEWW.js";
import "./chunk-WDMUDEB6.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
